package pt.unl.fct.di.aldeia.apdc2021.data.model;

public class UserUpdateData {
    private String token;
    private String email;
    private String full_name;
    private String profile;
    private String landline;
    private String mobile;
    private String address;
    private String address2;
    private String region;
    private String pc;
    private String website;
    private String facebook;
    private String instagram;
    private String twitter;

    public UserUpdateData(String email, String token, String full_name, String profile, String landline,
                        String mobile, String address, String address2, String region, String pc, String website, String facebook, String instagram, String twitter) {
        this.token = token;
        this.email = email;
        this.full_name = full_name;
        this.profile = profile;
        this.landline = landline;
        this.mobile = mobile;
        this.address = address;
        this.address2 = address2;
        this.region = region;
        this.pc = pc;
        this.website = website;
        this.facebook = facebook;
        this.instagram = instagram;
        this.twitter = twitter;
    }

    public String getToken() {
        return token;
    }

    public String getEmail() {
        return email;
    }

    public String getFullName() {
        return full_name;
    }

    public String getProfile() {
        return profile;
    }

    public String getLandline() {
        return landline;
    }

    public String getMobile() {
        return mobile;
    }

    public String getAddress() {
        return address;
    }

    public String getAddress2() {
        return address2;
    }

    public String getRegion() {
        return region;
    }

    public String getPc() {
        return pc;
    }

    public String getWebsite() {
        return website;
    }

    public String getFacebook() {
        return facebook;
    }

    public String getInstagram() {
        return instagram;
    }

    public String getTwitter() {
        return twitter;
    }


}
