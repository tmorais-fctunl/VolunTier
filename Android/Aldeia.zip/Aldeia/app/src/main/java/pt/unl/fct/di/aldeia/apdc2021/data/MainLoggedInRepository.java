package pt.unl.fct.di.aldeia.apdc2021.data;

import pt.unl.fct.di.aldeia.apdc2021.data.model.UserUpdateData;

public class MainLoggedInRepository {
    private static volatile MainLoggedInRepository instance;

    private ChangeProfileDataSource changeProfileDataSource;
    private LogoutDataSource logoutDataSource;

    // private constructor : singleton access
    private MainLoggedInRepository(ChangeProfileDataSource changeProfileDataSource,LogoutDataSource logoutDataSource) {
        this.changeProfileDataSource=changeProfileDataSource;
        this.logoutDataSource=logoutDataSource;
    }

    public static MainLoggedInRepository getInstance(ChangeProfileDataSource changeProfileDataSource, LogoutDataSource logoutDataSource) {
        if (instance == null) {
            instance = new MainLoggedInRepository(changeProfileDataSource,logoutDataSource);
        }
        return instance;
    }
    public Result<Void> logout(String username, String token) {
        return logoutDataSource.logout(username, token);
    }

    public Result<Void> updateProfileData(UserUpdateData user){
        return changeProfileDataSource.changeProfileAttributes(user);
    }


}
