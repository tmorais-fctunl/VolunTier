package pt.unl.fct.di.aldeia.apdc2021.ui.mainLoggedIn;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.NavigationUI;

import pt.unl.fct.di.aldeia.apdc2021.App;
import pt.unl.fct.di.aldeia.apdc2021.R;
import pt.unl.fct.di.aldeia.apdc2021.data.model.UserAuthenticated;
import pt.unl.fct.di.aldeia.apdc2021.data.model.UserFullData;
import pt.unl.fct.di.aldeia.apdc2021.data.model.UserLocalStore;
import pt.unl.fct.di.aldeia.apdc2021.data.model.UserUpdateData;
import pt.unl.fct.di.aldeia.apdc2021.ui.login.LoginActivity;
import pt.unl.fct.di.aldeia.apdc2021.ui.refresh.RefreshActivity;
import pt.unl.fct.di.aldeia.apdc2021.ui.validate.ValidateActivity;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainLoggedInActivity extends AppCompatActivity {
    private static final int VALIDATION=1;
    private static final int REFRESH=2;
    private UserLocalStore storage;
    private MainLoggedInViewModel viewModel;
    private MainLoggedInActivity mActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mActivity=this;
       // viewModel = new ViewModelProvider(this).get(MainLoggedInViewModel.class);
        viewModel= new ViewModelProvider(this, new MainLoggedInViewModelFactory(((App) getApplication()).getExecutorService()))
                .get(MainLoggedInViewModel.class);
        storage = new UserLocalStore(this);
        UserAuthenticated userAuthenticated= storage.getLoggedInUser();
        UserFullData userFullData = storage.getUserFullData();
        viewModel.setUserAuthData(userAuthenticated);
        viewModel.setUserFullData(userFullData);
        setContentView(R.layout.test);
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigationView);
        NavHostFragment navHostFragment = (NavHostFragment) getSupportFragmentManager().findFragmentById(R.id.fragmentContainerView);
        NavController navController = navHostFragment.getNavController();
        //NavController navController = Navigation.findNavController(this,  R.id.fragmentContainerView);
        // AppBarConfiguration appBarConfiguration=AppBarConfiguration
        NavigationUI.setupWithNavController(bottomNavigationView, navController);

        viewModel.getTransitionHandler().observe(this, new Observer<MainLoggedInActivityTransitionHandler>() {
            @Override
            public void onChanged(@Nullable MainLoggedInActivityTransitionHandler transitionHandler) {
                UserAuthenticated user=storage.getLoggedInUser();
                if (System.currentTimeMillis()<user.getExpirationDate()){
                    Intent intent = new Intent(mActivity, ValidateActivity.class);
                    startActivityForResult(intent,VALIDATION);
                }
                else if(System.currentTimeMillis()<user.getRefresh_expirationDate()){
                    Intent intent = new Intent(mActivity, RefreshActivity.class);
                    startActivityForResult(intent,REFRESH);
                }
                switch (transitionHandler.getTransition()){
                    case "Logout":
                        viewModel.logout(userAuthenticated.getEmail(),userAuthenticated.getTokenID());
                        break;
                    case "Update Data":
                        UserUpdateData userUpdate=viewModel.getUserUpdateData();
                        viewModel.updateProfileData(userUpdate);
                        storage.storeUserFullData(new UserFullData(userFullData.getUsername(),userFullData.getEmail(),userUpdate.getFullName(),userUpdate.getProfile(),userUpdate.getLandline(),userUpdate.getMobile()
                                ,userUpdate.getAddress(),userUpdate.getAddress2(),userUpdate.getRegion(),userUpdate.getPc(),userUpdate.getWebsite(),userUpdate.getFacebook(),userUpdate.getInstagram(), userUpdate.getTwitter()));
                        break;
                    case "Remove":
                        RemoveAccDialog dialog = new RemoveAccDialog();
                        dialog.show(navHostFragment.getFragmentManager(),"");
                        break;
                    default:
                        //do nothing
                        break;
                }
            }
        });
        viewModel.getLogoutResult().observe(this, new Observer<LogoutResult>() {
            @Override
            public void onChanged(@Nullable LogoutResult logoutResult) {
                if (logoutResult == null) {
                    return;
                }
                if (logoutResult.getError() != null) {
                    setResult(Activity.RESULT_CANCELED);
                }
                if (logoutResult.getSuccess() != null) {
                    setResult(Activity.RESULT_OK);
                    storage.clearUserData();
                    Intent intent = new Intent(mActivity, LoginActivity.class);
                    startActivity(intent);
                    finish();
                }

            }
        });
        viewModel.getUpdateDataResult().observe(this, new Observer<UpdateDataResult>() {
            @Override
            public void onChanged(@Nullable UpdateDataResult updateDataResult) {
                if (updateDataResult == null) {
                    return;
                }
                if (updateDataResult.getError() != null) {
                    Toast.makeText(mActivity, updateDataResult.getError(), Toast.LENGTH_SHORT).show();
                }
                if (updateDataResult.getSuccess() != null) {

                    Toast.makeText(mActivity, updateDataResult.getSuccess(), Toast.LENGTH_SHORT).show();
                }

            }
        });

        viewModel.getUserFullDataLD().observe(this, new Observer<UserFullData>() {
            @Override
            public void onChanged(@Nullable UserFullData user) {
                storage.storeUserFullData(user);
            }
        });
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==VALIDATION || requestCode==REFRESH)
        {
            if(resultCode != Activity.RESULT_OK){
                Intent intent = new Intent(mActivity, LoginActivity.class);
                startActivity(intent);
                finish();
            }
        }
    }
    public static class RemoveAccDialog extends DialogFragment {
        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            // Use the Builder class for convenient dialog construction
            AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
            builder.setMessage("Are you sure you want to delete your account?")
                    .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            dialog.dismiss();
                        }
                    })
                    .setNegativeButton("No", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            dialog.dismiss();
                        }
                    });
            // Create the AlertDialog object and return it
            return builder.create();
        }
    }
}