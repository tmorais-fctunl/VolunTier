package pt.unl.fct.di.aldeia.apdc2021.ui.mainLoggedIn;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Transformations;

import java.util.ArrayList;
import java.util.List;

import pt.unl.fct.di.aldeia.apdc2021.data.Room.EventEntity;
import pt.unl.fct.di.aldeia.apdc2021.data.Room.EventsRoomRepository;

public class RoomViewModel extends AndroidViewModel {
    private EventsRoomRepository repository;
    private LiveData<List<EventEntity>> queryResult=new MutableLiveData<>();
    private List<String> hashesConsulted;
    private MutableLiveData<String> GeoHash = new MutableLiveData<String>();
    private LiveData<List<EventEntity>> events = Transformations.switchMap(GeoHash, (geoHash -> repository.geEventsByHashLoc(geoHash)));

    public RoomViewModel(Application application){
        super(application);
        repository= new EventsRoomRepository(application);
        hashesConsulted=new ArrayList<>();
    }

    public void setCurrentGeoHash(String geoHash){
        GeoHash.postValue(geoHash);
    }


    public List<String> getHashesConsulted(){return hashesConsulted;}

    public void insertMultipleEvents(List<EventEntity> events) { repository.insertMultipleEvents(events); }

    public void insertEvent(EventEntity event){
        repository.insertEvent(event);
    }

    public void eventsByLoc(String hashedLoc){
        queryResult = repository.geEventsByHashLoc(hashedLoc);
    }

    public LiveData<List<EventEntity>> getQueryResult(){
        return events;
    }

    public void updateEvent(EventEntity event){
        repository.updateEvent(event);
    }

    public void deleteEvent(String id){
        repository.deleteEvent(new EventEntity(id,0,0,null,0,null,null,null));
    }
}
