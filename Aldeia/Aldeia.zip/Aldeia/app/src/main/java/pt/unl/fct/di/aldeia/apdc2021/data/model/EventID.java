package pt.unl.fct.di.aldeia.apdc2021.data.model;

public class EventID {

    String event_id;

    EventID(String event_id) {
        this.event_id=event_id;
    }

    public String getEventID() {
        return event_id;
    }
}
