package pt.unl.fct.di.aldeia.apdc2021.data;

import pt.unl.fct.di.aldeia.apdc2021.data.model.CreateEventData;
import pt.unl.fct.di.aldeia.apdc2021.data.model.EventID;
import pt.unl.fct.di.aldeia.apdc2021.data.model.SearchEventsData;
import pt.unl.fct.di.aldeia.apdc2021.data.model.SearchEventsReply;
import pt.unl.fct.di.aldeia.apdc2021.data.model.UpdatePhotoData;
import pt.unl.fct.di.aldeia.apdc2021.data.model.UpdatePhotoReply;
import pt.unl.fct.di.aldeia.apdc2021.data.model.UserUpdateData;

public class MainLoggedInRepository {
    private static volatile MainLoggedInRepository instance;

    private final ChangeProfileDataSource changeProfileDataSource;
    private final LogoutDataSource logoutDataSource;
    private final RemoveAccDataSource removeAccDataSource;
    private final AddEventDataSource addEventDataSource;
    private final UpdatePhotoDataSource updatePhotoDataSource;
    private final UploadPhotoGCDataSource uploadPhotoGCDataSource;
    private final SearchEventsDataSource searchEventsDataSource;


    // private constructor : singleton access
    private MainLoggedInRepository(ChangeProfileDataSource changeProfileDataSource, LogoutDataSource logoutDataSource
            , RemoveAccDataSource removeAccDataSource, AddEventDataSource addEventDataSource
    , UpdatePhotoDataSource updatePhotoDataSource, UploadPhotoGCDataSource uploadPhotoGCDataSource,SearchEventsDataSource searchEventsDataSource) {
        this.updatePhotoDataSource=updatePhotoDataSource;
        this.changeProfileDataSource=changeProfileDataSource;
        this.logoutDataSource=logoutDataSource;
        this.removeAccDataSource=removeAccDataSource;
        this.addEventDataSource = addEventDataSource;
        this.uploadPhotoGCDataSource = uploadPhotoGCDataSource;
        this.searchEventsDataSource=searchEventsDataSource;
    }

    public static MainLoggedInRepository getInstance(ChangeProfileDataSource changeProfileDataSource, LogoutDataSource logoutDataSource
            , RemoveAccDataSource removeAccDataSource, AddEventDataSource addEventDataSource, UpdatePhotoDataSource updatePhotoDataSource
            , UploadPhotoGCDataSource uploadPhotoGCDataSource,SearchEventsDataSource searchEventsDataSource) {
        if (instance == null) {
            instance = new MainLoggedInRepository(changeProfileDataSource,logoutDataSource,removeAccDataSource, addEventDataSource
                    ,updatePhotoDataSource, uploadPhotoGCDataSource,searchEventsDataSource);
        }
        return instance;
    }
    public Result<Void> logout(String username, String token) {
        return logoutDataSource.logout(username, token);
    }

    public Result<Void> updateProfileData(UserUpdateData user){
        return changeProfileDataSource.changeProfileAttributes(user);
    }

    public Result<Void> removeAccDataSource(String email,String token, String target){
        return removeAccDataSource.removeUser(email,token, target);
    }

    public Result<EventID> addEventDataSource (CreateEventData event) {
        return addEventDataSource.addEvent(event);
    }

    public Result<UpdatePhotoReply> updatePhoto(UpdatePhotoData data){
        return updatePhotoDataSource.updateEvent(data);
    }
    public Result<Void> updatePhotoGC(String url,byte[]data){
        return uploadPhotoGCDataSource.uploadPhotoGC(data,url);
    }

    public Result<SearchEventsReply> searchEvents(SearchEventsData data){
        return searchEventsDataSource.searchEvent(data);
    }
}
