package pt.unl.fct.di.aldeia.apdc2021.data.Room;

import android.app.Application;

import androidx.lifecycle.LiveData;

import java.util.List;

public class EventsRoomRepository {

    private EventDao eventDao;

    public EventsRoomRepository(Application application) {
        EventsDatabase db = EventsDatabase.getDatabase(application);
        eventDao = db.eventDao();
    }

    public LiveData<List<EventEntity>> geEventsByHashLoc(String location) {
        return eventDao.loadAllEventsFromLoc(location);
    }



    // You must call this on a non-UI thread or your app will throw an exception. Room ensures
    // that you're not doing any long running operations on the main thread, blocking the UI.
    public void insertMultipleEvents(List<EventEntity> events) {
        EventsDatabase.databaseWriteExecutor.execute(() -> {
            eventDao.insertEvents(events);
        });
    }

    public void insertEvent(EventEntity event){
        EventsDatabase.databaseWriteExecutor.execute(() -> {
            eventDao.insertEvent(event);
        });
    }

    public void updateEvent(EventEntity event){
        EventsDatabase.databaseWriteExecutor.execute(() -> {
            eventDao.updateEvent(event);
        });
    }

    public void deleteEvent(EventEntity id){
        EventsDatabase.databaseWriteExecutor.execute(() -> {
            eventDao.delete(id);
        });
    }

}
