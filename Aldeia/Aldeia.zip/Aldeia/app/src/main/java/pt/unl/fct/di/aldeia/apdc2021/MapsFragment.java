package pt.unl.fct.di.aldeia.apdc2021;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.icu.util.Calendar;
import android.location.Location;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;

import org.jetbrains.annotations.NotNull;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

import pt.unl.fct.di.aldeia.apdc2021.data.Room.EventEntity;
import pt.unl.fct.di.aldeia.apdc2021.data.model.EventMarkerData;
import pt.unl.fct.di.aldeia.apdc2021.data.model.SearchEventsData;
import pt.unl.fct.di.aldeia.apdc2021.data.model.SearchEventsReplyUnit;
import pt.unl.fct.di.aldeia.apdc2021.data.model.UserAuthenticated;
import pt.unl.fct.di.aldeia.apdc2021.ui.mainLoggedIn.AddEventResult;
import pt.unl.fct.di.aldeia.apdc2021.ui.mainLoggedIn.GeoHashUtil;
import pt.unl.fct.di.aldeia.apdc2021.ui.mainLoggedIn.MainLoggedInActivityTransitionHandler;
import pt.unl.fct.di.aldeia.apdc2021.ui.mainLoggedIn.MainLoggedInViewModel;
import pt.unl.fct.di.aldeia.apdc2021.ui.mainLoggedIn.RoomViewModel;
import pt.unl.fct.di.aldeia.apdc2021.ui.mainLoggedIn.SearchEventsResult;
import pt.unl.fct.di.aldeia.apdc2021.ui.mainLoggedIn.UpdateDataResult;

public class MapsFragment extends Fragment {

    SupportMapFragment mapFragment;
    FusedLocationProviderClient client;
    private LatLng curLoc = new LatLng(38.66027149660053,  -9.20960571616888);
    private GoogleMap gmap;
    private List<String> hashesConsulted;
    private List<Marker> markers;
    private List<String> hashesLoaded;
    private MainLoggedInViewModel viewModel;
    private RoomViewModel roomViewModel;
    private boolean creating;
    private boolean areEventsVisible;
    private MapsFragment mFragment;
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        viewModel = new ViewModelProvider(requireActivity()).get(MainLoggedInViewModel.class);
        roomViewModel=new ViewModelProvider(requireActivity()).get(RoomViewModel.class);
        mapFragment = (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.mapsFragment);
        final ImageButton createEvent = view.findViewById(R.id.createEventButton);
        final TextView eventChoose = view.findViewById(R.id.eventChoose);
        creating = false;
        hashesConsulted= roomViewModel.getHashesConsulted();
        hashesLoaded= new ArrayList<>();
        viewModel.resetSearch();
        markers=new ArrayList<Marker>();
        mFragment=this;


        createEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                creating = true;
                createEvent.setVisibility(View.INVISIBLE);
                eventChoose.setVisibility(View.VISIBLE);
            }
        });
        mapFragment.getMapAsync(new OnMapReadyCallback() {
            @Override
            public void onMapReady(GoogleMap googleMap) {
                gmap = googleMap;
                gmap.setMinZoomPreference(7);
                if(ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION)
                        == PackageManager.PERMISSION_GRANTED) {
                    getCurrentLocation();
                } else {
                    requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION},44);
                }
                gmap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
                    @Override
                    public void onMapClick(LatLng latLng) {
                        if (creating) {
                            eventChoose.setVisibility(View.INVISIBLE);
                            viewModel.setEventCoordinates(latLng);
                            viewModel.setTransitionHandler(new MainLoggedInActivityTransitionHandler("Create Event"));
                            creating = false;
                        }
                    }
                });
                gmap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
                    @Override
                    public boolean onMarkerClick(Marker marker) {
                        viewModel.setEvent_id(marker.getTitle());
                        viewModel.setTransitionHandler(new MainLoggedInActivityTransitionHandler("Event Info"));
                        return false;
                    }
                });
                gmap.setOnCameraMoveListener(new GoogleMap.OnCameraMoveListener() {
                    @Override
                    public void onCameraMove() {
                        CameraPosition cameraPosition = googleMap.getCameraPosition();
                        if(areEventsVisible && cameraPosition.zoom < 9.0) {
                            areEventsVisible=false;
                            hideEvents();
                        } else if (!areEventsVisible && cameraPosition.zoom>=9.0) {
                            areEventsVisible=true;
                            showEvents();
                        }
                        if(!hashesLoaded.contains(GeoHashUtil.convertCoordsToGeoHashLowPrecision(cameraPosition.target.latitude,cameraPosition.target.longitude))){
                            loadEvents(cameraPosition.target.latitude,cameraPosition.target.longitude);
                        }
                    }
                });
                roomViewModel.getQueryResult().observe(mapFragment.getViewLifecycleOwner(), new Observer<List<EventEntity>>() {
                    @Override
                    public void onChanged(List<EventEntity> eventEntities) {
                        if (eventEntities.isEmpty()){

                        }else{
                            Iterator<EventEntity> it = eventEntities.iterator();
                            List<EventEntity> entities=new ArrayList<EventEntity>();
                            while (it.hasNext()){
                                EventEntity current=it.next();
                                LatLng coordinates = new LatLng(current.getLatitude(), current.getLongitude());
                                MarkerOptions marker = new MarkerOptions();
                                marker.position(coordinates);
                                marker.title(current.getEvent_id());
                                markers.add(gmap.addMarker(marker));
                            }

                        }
                    }
                });
                viewModel.getAddEventResult().observe(mapFragment.getViewLifecycleOwner(), new Observer<AddEventResult>() {
                    @Override
                    public void onChanged(@Nullable AddEventResult addEventResult) {
                        if(addEventResult == null) {
                            return;
                        }
                        if (addEventResult.getSuccess() != null) {
                            EventEntity event = addEventResult.getSuccess();
                            LatLng coordinates = new LatLng(event.getLatitude(), event.getLongitude());
                            MarkerOptions marker = new MarkerOptions();
                            marker.position(coordinates);
                            marker.title(event.getEvent_id());
                            roomViewModel.insertEvent(event);
                            markers.add(gmap.addMarker(marker));
                        }
                    }
                });

                viewModel.getSearchEventsResult().observe(mapFragment.getViewLifecycleOwner(), new Observer<SearchEventsResult>() {
                    @Override
                    public void onChanged(@Nullable SearchEventsResult searchEventsResult) {
                        if(searchEventsResult == null) {
                            return;
                        }
                        if (searchEventsResult.getSuccess() != null) {
                            List<SearchEventsReplyUnit> events =searchEventsResult.getSuccess().getEvents();
                            Iterator<SearchEventsReplyUnit> it = events.iterator();
                            List<EventEntity> entities=new ArrayList<EventEntity>();
                            while (it.hasNext()){
                                SearchEventsReplyUnit current=it.next();
                                if(compareDate(current.getEnd_date())){
                                    EventEntity aux= new EventEntity(current.getEvent_id(),current.getLocation()[0],current.getLocation()[1],current.getName(),
                                            current.getNum_participants(),current.getStart_date(),current.getEnd_date(),searchEventsResult.getSuccess().getRegion_hash());
                                    entities.add(aux);
                                    LatLng coordinates = new LatLng(current.getLocation()[0], current.getLocation()[1]);
                                    MarkerOptions marker = new MarkerOptions();
                                    marker.position(coordinates);
                                    marker.title(current.getEvent_id());
                                    markers.add(gmap.addMarker(marker));
                                }

                            }
                            roomViewModel.insertMultipleEvents(entities);
                        }

                    }
                });

                viewModel.getDeletedEvent().observe(mapFragment.getViewLifecycleOwner(), new Observer<String>() {
                    @Override
                    public void onChanged(String s) {
                        if(s==null){
                            return;
                        }
                        Iterator<Marker> it=markers.iterator();
                        while(it.hasNext()){
                            Marker aux=it.next();
                            if(aux.getTitle().equals(s)){
                                aux.setVisible(false);
                                markers.remove(aux);
                                return;
                            }
                        }
                    }
                });

                viewModel.getUpdatedEvent().observe(mapFragment.getViewLifecycleOwner(), new Observer<EventMarkerData>() {
                    @Override
                    public void onChanged(EventMarkerData updatedEvent) {
                        if(updatedEvent==null){
                            return;
                        }
                        Iterator<Marker> it=markers.iterator();
                        while(it.hasNext()){
                            Marker aux=it.next();
                            if(aux.getTitle().equals(updatedEvent.getEvent_id())){
                                aux.setPosition(new LatLng(updatedEvent.getCoordinates()[0],updatedEvent.getCoordinates()[1]));
                                CameraPosition pos = CameraPosition.builder().target(curLoc).zoom(15).build();
                                gmap.moveCamera(CameraUpdateFactory.newCameraPosition(pos));
                                return;
                            }
                        }
                    }
                });
            }
        });



    }

    private boolean compareDate(String endDate){
        SimpleDateFormat formatD = new SimpleDateFormat("yyyy-MM-dd-HH:mm");
        String currentDate = formatD.format(new Date());
        String eDate = endDate.substring(0,endDate.indexOf("T"));
        eDate = eDate.concat("-").concat(endDate.substring(endDate.indexOf("T")+1, endDate.length()-4));
        try {
            int a = 2;
            Date cD = formatD.parse(currentDate);
            Date eD = formatD.parse(eDate);
            if(cD.compareTo(eD) > 0) {
                return false;
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return true;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_maps, container, false);
        client = LocationServices.getFusedLocationProviderClient(getActivity());
        return view;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull @NotNull String[] permissions, @NonNull @NotNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 44 && grantResults.length>0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            getCurrentLocation();
        }
        else {
            Toast.makeText(getActivity(), "Permission denied", Toast.LENGTH_SHORT).show();
        }
    }

    @SuppressLint("MissingPermission")
    private void getCurrentLocation () {
        Task<Location> task = client.getLastLocation();
        task.addOnSuccessListener(new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                if(location != null) {
                    mapFragment.getMapAsync(new OnMapReadyCallback() {
                        @Override
                        public void onMapReady(GoogleMap googleMap) {
                            loadEvents(location.getLatitude(),location.getLongitude());
                            curLoc = new LatLng(location.getLatitude(), location.getLongitude());
                            BitmapDescriptor bitmap = BitmapFromVector(getActivity(), R.drawable.ic_your_location);
                            MarkerOptions options = new MarkerOptions().position(curLoc).title("You are here").icon(bitmap);
                            CameraPosition pos = CameraPosition.builder().target(curLoc).zoom(15).build();
                            areEventsVisible=true;
                            googleMap.moveCamera(CameraUpdateFactory.newCameraPosition(pos));
                            markers.add(googleMap.addMarker(options));
                        }
                    });
                }
            }
        });
    }

    private void loadEvents(Double lat,Double lon){
        String hashedLoc=GeoHashUtil.convertCoordsToGeoHashLowPrecision(lat,lon);
        if(hashesConsulted.contains(hashedLoc)){
            roomViewModel.setCurrentGeoHash(GeoHashUtil.convertCoordsToGeoHashLowPrecision(lat,lon));
        }
        else{
            hashesConsulted.add(hashedLoc);
            UserAuthenticated userAuth=viewModel.getUserAuth();
            double[] coords= {lat,lon};
            viewModel.searchEvents(new SearchEventsData(userAuth.getEmail(), userAuth.getTokenID(), coords ));
        }
        hashesLoaded.add(hashedLoc);


    }




    private BitmapDescriptor BitmapFromVector(Context context, int vectorResId) {
        // below line is use to generate a drawable.
        Drawable vectorDrawable = ContextCompat.getDrawable(context, vectorResId);

        // below line is use to set bounds to our vector drawable.
        vectorDrawable.setBounds(0, 0, vectorDrawable.getIntrinsicWidth(), vectorDrawable.getIntrinsicHeight());

        // below line is use to create a bitmap for our
        // drawable which we have added.
        Bitmap bitmap = Bitmap.createBitmap(vectorDrawable.getIntrinsicWidth(), vectorDrawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);

        // below line is use to add bitmap in our canvas.
        Canvas canvas = new Canvas(bitmap);

        // below line is use to draw our
        // vector drawable in canvas.
        vectorDrawable.draw(canvas);

        // after generating our bitmap we are returning our bitmap.
        return BitmapDescriptorFactory.fromBitmap(bitmap);
    }

    private void hideEvents(){
        Iterator<Marker> it=markers.iterator();
        while(it.hasNext()){
            Marker aux=it.next();
            if(!aux.getTitle().equals("You are here")){
                aux.setVisible(false);
            }
        }
    }
    private void showEvents(){
        Iterator<Marker> it=markers.iterator();
        while(it.hasNext()){
            it.next().setVisible(true);
        }
    }


}