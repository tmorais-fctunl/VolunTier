package pt.unl.fct.di.aldeia.apdc2021.data.model;

public class UpdatePhotoReply {
    private String url;

    public UpdatePhotoReply(String url) {
        this.url = url;
    }

    public String getUrl() {
        return url;
    }
}
