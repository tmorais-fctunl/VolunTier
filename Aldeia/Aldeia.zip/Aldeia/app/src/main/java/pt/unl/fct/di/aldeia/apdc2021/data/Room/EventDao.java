package pt.unl.fct.di.aldeia.apdc2021.data.Room;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface EventDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertEvents(List<EventEntity> events);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertEvent(EventEntity event);

    @Update
    void updateEvent(EventEntity event);

    @Delete
    void delete(EventEntity event);

    @Query("DELETE FROM EventEntity")
    void nukeTable();

    @Query("SELECT * FROM EventEntity WHERE hashed_location = :hashedLocation")
    LiveData<List<EventEntity>> loadAllEventsFromLoc(String hashedLocation);
}
