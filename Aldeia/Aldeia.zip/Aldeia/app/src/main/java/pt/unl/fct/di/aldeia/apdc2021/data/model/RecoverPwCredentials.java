package pt.unl.fct.di.aldeia.apdc2021.data.model;

public class RecoverPwCredentials {
    String email;

    public RecoverPwCredentials(String email) {
        this.email=email;
    }

    public String getEmail() {
        return email;
    }

}