package pt.unl.fct.di.aldeia.apdc2021.ui.event;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import com.google.android.gms.maps.model.LatLng;

import java.util.Calendar;

import pt.unl.fct.di.aldeia.apdc2021.App;
import pt.unl.fct.di.aldeia.apdc2021.R;
import pt.unl.fct.di.aldeia.apdc2021.data.Room.EventEntity;
import pt.unl.fct.di.aldeia.apdc2021.data.model.EventFullData;
import pt.unl.fct.di.aldeia.apdc2021.data.model.EventUpdateData;
import pt.unl.fct.di.aldeia.apdc2021.data.model.UserAuthenticated;
import pt.unl.fct.di.aldeia.apdc2021.data.model.UserLocalStore;
import pt.unl.fct.di.aldeia.apdc2021.ui.mainLoggedIn.GeoHashUtil;
import pt.unl.fct.di.aldeia.apdc2021.ui.mainLoggedIn.MainLoggedInActivity;
import pt.unl.fct.di.aldeia.apdc2021.ui.mainLoggedIn.RoomViewModel;
import pt.unl.fct.di.aldeia.apdc2021.ui.refresh.RefreshActivity;

public class GetEventActivity extends AppCompatActivity {

    private final int CHANGE_LOC = 7;

    private UserLocalStore storage;
    private GetEventViewModel getEventViewModel;
    private GetEventActivity mActivity;
    private EventFullData initialEvent;
    private RoomViewModel roomViewModel;
    private int hour, min;
    private boolean wasLocChanged;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle extras = getIntent().getExtras();
        String event_id = null;
        if (extras != null) {
            event_id = extras.getString("event_id");
        }
        setContentView(R.layout.event_page);
        storage= new UserLocalStore(this);
        getEventViewModel = new ViewModelProvider(this, new GetEventViewModelFactory(((App) getApplication()).getExecutorService()))
                .get(GetEventViewModel.class);
        roomViewModel=new RoomViewModel(getApplication());
        mActivity=this;
        wasLocChanged=false;
        final EditText eventNameEditText = findViewById(R.id.event_page_name);
        final Button eventStartDayButton = findViewById(R.id.event_page_startDate);
        final Button eventEndDayButton = findViewById(R.id.event_page_endDate);
        final Button eventStartHourButton = findViewById(R.id.event_page_startTime);
        final Button eventEndHourButton = findViewById(R.id.event_page_endTime);
        final EditText eventOwnerEmailEditText = findViewById(R.id.event_page_owner_email);
        final EditText eventOwnerContactEditText = findViewById(R.id.event_page_owner_contact);
        final EditText eventDescriptionEditText = findViewById(R.id.event_page_description);
        final Spinner eventCategorySpinner = findViewById(R.id.event_page_category);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.categories));
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        eventCategorySpinner.setAdapter(adapter);
        final EditText eventCapacityEditText = findViewById(R.id.event_page_capacity);
        final EditText eventWebsiteEditText = findViewById(R.id.event_page_website);
        final EditText eventFacebookEditText = findViewById(R.id.event_page_facebook);
        final EditText eventTwitterEditText = findViewById(R.id.event_page_twitter);
        final EditText eventInstagramEditText = findViewById(R.id.event_page_instagram);
        final Switch eventProfileSwitch = findViewById(R.id.event_switch_profile);
        final Button eventDeleteButton =findViewById(R.id.event_page_delete);
        final Button eventChangeLocationButton =findViewById(R.id.event_page_location);
        final Button eventChatButton =findViewById(R.id.event_page_comments);
        final Button eventSaveButton =findViewById(R.id.event_page_save);
        final Button eventCancelButton =findViewById(R.id.event_page_cancel);
        final ProgressBar eventProgressBar=findViewById(R.id.eventProgressBar);
        eventProgressBar.setVisibility(View.VISIBLE);

        UserAuthenticated user = storage.getLoggedInUser();
        getEventViewModel.getEvent(user.getEmail(), user.getTokenID(), event_id);

        getEventViewModel.getGetEventResult().observe(this, new Observer<GetEventResult>() {
            @Override
            public void onChanged(@Nullable GetEventResult getEventResult) {
                if (getEventResult == null) {
                    return;
                }
                if (getEventResult.getError() != null) {
                    Toast.makeText(mActivity, "Event Retrieval Unsuccessful", Toast.LENGTH_SHORT).show();
                    finish();
                }
                if (getEventResult.getSuccess() != null) {
                    EventFullData eventFullData = getEventResult.getSuccess();
                    getEventViewModel.setEventCoordinates(eventFullData.getLocation());
                    initialEvent=eventFullData;
                    eventNameEditText.setText(eventFullData.getName());
                    String startDate = eventFullData.getStartDate();
                    int pos = startDate.indexOf("T")+1;
                    String day = startDate.substring(0,pos);
                    String time = startDate.substring(pos);
                    eventStartDayButton.setText(day);
                    eventStartHourButton.setText(time);
                    String endDate = eventFullData.getEndDate();
                    pos = endDate.indexOf("T")+1;
                    day = endDate.substring(0,pos);
                    time = endDate.substring(pos);
                    eventEndDayButton.setText(day);
                    eventEndHourButton.setText(time);
                    eventOwnerEmailEditText.setText(eventFullData.getOwnerEmail());
                    eventOwnerContactEditText.setText(eventFullData.getContact());
                    eventDescriptionEditText.setText(eventFullData.getDescription());
                    if (eventFullData.getCategory() != null) {
                        int spinnerPosition = adapter.getPosition(eventFullData.getCategory());
                        eventCategorySpinner.setSelection(spinnerPosition);
                    }
                    eventCapacityEditText.setText(String.valueOf(eventFullData.getCapacity()));
                    eventWebsiteEditText.setText(eventFullData.getWebsite());
                    eventFacebookEditText.setText(eventFullData.getFacebook());
                    eventTwitterEditText.setText(eventFullData.getTwitter());
                    eventInstagramEditText.setText(eventFullData.getInstagram());
                    switch(eventFullData.getProfile().toUpperCase()){
                        case "PRIVATE":
                            eventProfileSwitch.setChecked(true);
                            break;
                        default:
                            eventProfileSwitch.setChecked(false);
                            break;
                    }
                    if(!eventFullData.getOwnerEmail().equals(user.getEmail())){
                        eventNameEditText.setClickable(false);
                        eventNameEditText.setFocusable(false);
                        eventStartDayButton.setClickable(false);
                        eventStartHourButton.setClickable(false);
                        eventEndDayButton.setClickable(false);
                        eventEndHourButton.setClickable(false);
                        eventOwnerEmailEditText.setClickable(false);
                        eventOwnerEmailEditText.setFocusable(false);
                        eventOwnerContactEditText.setClickable(false);
                        eventOwnerContactEditText.setFocusable(false);
                        eventDescriptionEditText.setClickable(false);
                        eventDescriptionEditText.setFocusable(false);
                        eventCategorySpinner.setClickable(false);
                        eventCapacityEditText.setClickable(false);
                        eventCapacityEditText.setFocusable(false);
                        eventWebsiteEditText.setClickable(false);
                        eventWebsiteEditText.setFocusable(false);
                        eventFacebookEditText.setClickable(false);
                        eventFacebookEditText.setFocusable(false);
                        eventTwitterEditText.setClickable(false);
                        eventTwitterEditText.setFocusable(false);
                        eventInstagramEditText.setClickable(false);
                        eventInstagramEditText.setFocusable(false);
                        eventProfileSwitch.setClickable(false);
                        eventDeleteButton.setClickable(false);
                        eventSaveButton.setClickable(false);
                        eventChangeLocationButton.setClickable(false);
                    }
                    eventProgressBar.setVisibility(View.INVISIBLE);
                }
            }
        });

        eventCancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent returnIntent = new Intent();
                setResult(Activity.RESULT_CANCELED,returnIntent);
                finish();
            }
        });

        getEventViewModel.getUpdateEventResult().observe(this, new Observer<UpdateEventResult>() {
            @Override
            public void onChanged(@Nullable UpdateEventResult updateEventResult) {
                if (updateEventResult == null) {
                    return;
                }
                if (updateEventResult.getError() != null) {
                    Toast.makeText(mActivity, "Event Update Unsuccessful", Toast.LENGTH_SHORT).show();
                    Intent returnIntent = new Intent();
                    setResult(Activity.RESULT_CANCELED,returnIntent);
                }
                if (updateEventResult.getSuccess() != null) {
                    Toast.makeText(mActivity, "Event Update Successful", Toast.LENGTH_SHORT).show();
                    EventUpdateData update= updateEventResult.getSuccess();
                    EventEntity event = new EventEntity(update.getEventId(),update.getLocation()[0],update.getLocation()[1],update.getEvent_name(),update.getCapacity(),
                            update.getStartDate(),update.getEndDate(), GeoHashUtil.convertCoordsToGeoHashLowPrecision(update.getLocation()[0],update.getLocation()[1]));
                    roomViewModel.updateEvent(event);
                    Intent returnIntent = new Intent();
                    if(wasLocChanged){
                        returnIntent.putExtra("operation","Update");
                        returnIntent.putExtra("id",event.getEvent_id());
                        returnIntent.putExtra("lat",event.getLatitude());
                        returnIntent.putExtra("lon",event.getLongitude());
                    }
                    setResult(Activity.RESULT_OK,returnIntent);
                }
                finish();
            }
        });

        getEventViewModel.getUpdateEventFormState().observe(this, new Observer<UpdateEventFormState>() {
            @Override
            public void onChanged(@Nullable UpdateEventFormState updateEventFormState) {
                if (updateEventFormState == null) {
                    return;
                }
                eventSaveButton.setEnabled(updateEventFormState.isDataValid());
                if (!eventOwnerContactEditText.getText().toString().equals("") && updateEventFormState.getContactError() != null) {
                    eventOwnerContactEditText.setError(getString(updateEventFormState.getContactError()));
                }
                if (updateEventFormState.getDateError() != null) {
                    eventStartDayButton.setError(getString(updateEventFormState.getDateError()));
                    eventStartHourButton.setError(getString(updateEventFormState.getDateError()));
                    eventEndDayButton.setError(getString(updateEventFormState.getDateError()));
                    eventEndHourButton.setError(getString(updateEventFormState.getDateError()));
                }else{
                    eventStartDayButton.setError(null);
                    eventStartHourButton.setError(null);
                    eventEndDayButton.setError(null);
                    eventEndHourButton.setError(null);
                }
                if (!eventWebsiteEditText.getText().toString().equals("") && updateEventFormState.getWebsiteError() != null) {
                    eventWebsiteEditText.setError(getString(updateEventFormState.getWebsiteError()));
                }
                if (!eventFacebookEditText.getText().toString().equals("") && updateEventFormState.getFacebookError() != null) {
                    eventFacebookEditText.setError(getString(updateEventFormState.getFacebookError()));
                }
                if (!eventInstagramEditText.getText().toString().equals("") && updateEventFormState.getInstagramError() != null) {
                    eventInstagramEditText.setError(getString(updateEventFormState.getInstagramError()));
                }
                if (!eventTwitterEditText.getText().toString().equals("") && updateEventFormState.getTwitterError() != null) {
                    eventTwitterEditText.setError(getString(updateEventFormState.getTwitterError()));
                }
                if (!eventDescriptionEditText.getText().toString().equals("") && updateEventFormState.getDescriptionError() != null) {
                    eventDescriptionEditText.setError(getString(updateEventFormState.getDescriptionError()));
                }
            }
        });

        TextWatcher afterTextChangedListener = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // ignore
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // ignore
            }

            @Override
            public void afterTextChanged(Editable s) {
               getEventViewModel.updateEventDataChanged(eventOwnerContactEditText.getText().toString(),
                        eventStartDayButton.getText().toString() + eventStartHourButton.getText().toString(),
                       eventEndDayButton.getText().toString() + eventEndHourButton.getText().toString(),
                        eventWebsiteEditText.getText().toString(),
                        eventFacebookEditText.getText().toString(),eventInstagramEditText.getText().toString(),
                        eventTwitterEditText.getText().toString(),eventDescriptionEditText.getText().toString());
            }
        };
        eventOwnerContactEditText.addTextChangedListener(afterTextChangedListener);
        eventStartDayButton.addTextChangedListener(afterTextChangedListener);
        eventEndDayButton.addTextChangedListener(afterTextChangedListener);
        eventStartHourButton.addTextChangedListener(afterTextChangedListener);
        eventEndHourButton.addTextChangedListener(afterTextChangedListener);
        eventWebsiteEditText.addTextChangedListener(afterTextChangedListener);
        eventFacebookEditText.addTextChangedListener(afterTextChangedListener);
        eventInstagramEditText.addTextChangedListener(afterTextChangedListener);
        eventTwitterEditText.addTextChangedListener(afterTextChangedListener);
        eventDescriptionEditText.addTextChangedListener(afterTextChangedListener);


        eventChangeLocationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mActivity, EditLocationActivity.class);
                intent.putExtra("coords", initialEvent.getLocation());
                startActivityForResult(intent, CHANGE_LOC);
            }
        });



        eventSaveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String privacy="PUBLIC";
                if(eventProfileSwitch.isChecked()){
                    privacy="PRIVATE";
                }

               EventUpdateData updatedEvent= new EventUpdateData(user.getEmail(), user.getTokenID(),initialEvent.getEventId(),getEventViewModel.getEventCoordinates(),
                       eventNameEditText.getText().toString(),eventStartDayButton.getText().toString() + eventStartHourButton.getText().toString(),
                       eventEndDayButton.getText().toString() + eventEndHourButton.getText().toString(),
                        eventOwnerContactEditText.getText().toString(),
                        eventDescriptionEditText.getText().toString(),eventCategorySpinner.getSelectedItem().toString(),
                        Integer.parseInt(eventCapacityEditText.getText().toString()),eventWebsiteEditText.getText().toString(),
                        eventFacebookEditText.getText().toString(),eventInstagramEditText.getText().toString(),
                        eventTwitterEditText.getText().toString(), privacy);
                getEventViewModel.updateEvent(updatedEvent);
            }
        });

        eventDeleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getEventViewModel.removeEvent(user.getEmail(), user.getTokenID(), initialEvent.getEventId());
            }
        });

        getEventViewModel.getRemoveEventResult().observe(this, new Observer<RemoveEventResult>() {
            @Override
            public void onChanged(RemoveEventResult removeEventResult) {
                if (removeEventResult == null) {
                    return;
                }
                if (removeEventResult.getError() != null) {
                    Toast.makeText(mActivity, removeEventResult.getError(), Toast.LENGTH_SHORT).show();
                    Intent returnIntent = new Intent();
                    setResult(Activity.RESULT_CANCELED,returnIntent);
                }
                if (removeEventResult.getSuccess() != null) {
                    Toast.makeText(mActivity, removeEventResult.getSuccess(), Toast.LENGTH_SHORT).show();
                    roomViewModel.deleteEvent(initialEvent.getEventId());
                    Intent returnIntent = new Intent();
                    returnIntent.putExtra("operation","Delete");
                    returnIntent.putExtra("id",initialEvent.getEventId());
                    setResult(Activity.RESULT_OK,returnIntent);
                }
                finish();
            }
        });

        eventStartHourButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TimePickerDialog.OnTimeSetListener onTimeSetListener = new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        String h;
                        String m;
                        hour = hourOfDay;
                        min = minute;
                        if(hourOfDay < 10) {
                            h = "0"+String.valueOf(hourOfDay);
                        }
                        else {
                            h = String.valueOf(hourOfDay);
                        }
                        if(minute<10) {
                            m = "0"+String.valueOf(minute);
                        }
                        else {
                            m = String.valueOf(minute);
                        }
                        String startTimeText = h+":"+m+":00Z";
                        eventStartHourButton.setText(startTimeText);
                    }
                };
                TimePickerDialog timePickerDialog = new TimePickerDialog(mActivity, onTimeSetListener,hour, min, true);
                timePickerDialog.setTitle("Select time");
                timePickerDialog.show();
            }
        });

        eventEndHourButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TimePickerDialog.OnTimeSetListener onTimeSetListener = new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        String h;
                        String m;
                        hour = hourOfDay;
                        min = minute;
                        if(hourOfDay < 10) {
                            h = "0"+String.valueOf(hourOfDay);
                        }
                        else {
                            h = String.valueOf(hourOfDay);
                        }
                        if(minute<10) {
                            m = "0"+String.valueOf(minute);
                        }
                        else {
                            m = String.valueOf(minute);
                        }
                        String endTimeText = h+":"+m+":00Z";
                        eventEndHourButton.setText(endTimeText);
                    }
                };
                TimePickerDialog timePickerDialog = new TimePickerDialog(mActivity, onTimeSetListener,hour, min, true);
                timePickerDialog.setTitle("Select Time");
                timePickerDialog.show();
            }
        });

        eventStartDayButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar cal = Calendar.getInstance();
                int y = cal.get(Calendar.YEAR);
                int m = cal.get(Calendar.MONTH);
                int d = cal.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog.OnDateSetListener onDateSetListener = new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        String monthText;
                        String dayText;
                        if(month < 9) {
                            monthText = "0"+String.valueOf(month+1);
                        }
                        else {
                            monthText= String.valueOf(month+1);
                        }
                        if (dayOfMonth<10) {
                            dayText = "0"+String.valueOf(dayOfMonth);
                        }
                        else {
                            dayText = String.valueOf(dayOfMonth);
                        }
                        String startDateText = String.valueOf(year)+"-"+monthText+"-"+dayText+"T";
                        eventStartDayButton.setText(startDateText);
                    }
                };
                DatePickerDialog datePickerDialog = new DatePickerDialog(mActivity, onDateSetListener, y, m, d);
                datePickerDialog.setTitle("Select Date");
                datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis());
                datePickerDialog.show();
            }
        });

        eventEndDayButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar cal = Calendar.getInstance();
                int y = cal.get(Calendar.YEAR);
                int m = cal.get(Calendar.MONTH);
                int d = cal.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog.OnDateSetListener onDateSetListener = new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        String monthText;
                        String dayText;
                        if(month < 9) {
                            monthText = "0"+String.valueOf(month+1);
                        }
                        else {
                            monthText= String.valueOf(month+1);
                        }
                        if (dayOfMonth<10) {
                            dayText = "0"+String.valueOf(dayOfMonth);
                        }
                        else {
                            dayText = String.valueOf(dayOfMonth);
                        }
                        String endDateText = String.valueOf(year)+"-"+monthText+"-"+dayText+"T";
                        eventEndDayButton.setText(endDateText);
                    }
                };
                DatePickerDialog datePickerDialog = new DatePickerDialog(mActivity, onDateSetListener, y, m, d);
                datePickerDialog.setTitle("Select Date");
                datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis());
                datePickerDialog.show();
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==CHANGE_LOC) {
            if (resultCode == Activity.RESULT_OK) {
                double[] coords =  {data.getDoubleExtra("lat", 0), data.getDoubleExtra("lon", 0)};
                getEventViewModel.setEventCoordinates(coords);
                wasLocChanged=true;
            }
        }
    }
}